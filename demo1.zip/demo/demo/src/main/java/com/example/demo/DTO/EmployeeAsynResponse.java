package com.example.demo.DTO;

import com.example.demo.model.Employee;

public class EmployeeAsynResponse {

	private Employee employee;
	private Long salary;

	public EmployeeAsynResponse() {
		super();
	}

	public EmployeeAsynResponse(Employee employee, Long salary) {
		super();
		this.employee = employee;
		this.salary = salary;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	public Long getSalary() {
		return salary;
	}

	public void setSalary(Long salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "EmployeeAsynResponse [employee=" + employee + ", salary=" + salary + "]";
	}

}
