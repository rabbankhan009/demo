package com.example.demo.service;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.demo.DTO.EmployeeAsynResponse;
import com.example.demo.model.Employee;
import com.example.demo.repo.EmployeeRepository;

@Service
public class EmployeeService {

	@Autowired
	private EmployeeRepository employeeRepository;

	@Autowired
	private RestTemplate restTemplate;

	@Async
	public CompletableFuture<Employee> getDataFromDb(Long empId) {

		long startTime = System.currentTimeMillis();
		System.out.println("Start Time:: " + startTime);
		Employee emp = employeeRepository.findById(empId).orElseThrow(() -> new RuntimeException("Employee not found"));
		long endTime = System.currentTimeMillis();
		System.out.println("End Time:: " + endTime);
		long diff = endTime - startTime;
		System.out.println("Differnce in db calls:: " + diff);
		return CompletableFuture.completedFuture(emp);
	}

	@Async
	public CompletableFuture<Long> getDataFromApi(Long empId) {
		String salaryApiUrl = "http://localhost:8081/api/employee/salary/" + empId;
		long startTime = System.currentTimeMillis();
		System.out.println("Start Time:: " + startTime);
		// Calling external Salary URL using Rest Tempate
		Long salary = restTemplate.getForObject(salaryApiUrl, Long.class);
		System.out.println("Salary:: " + salary);
		long endTime = System.currentTimeMillis();
		System.out.println("End Time:: " + endTime);
		long diff = endTime - startTime;
		System.out.println("Differnce in API calls:: " + diff);
		return CompletableFuture.completedFuture(salary);
	}

	public EmployeeAsynResponse getEmployeeDetails(Long empId) throws InterruptedException, ExecutionException {
		long startTime = System.currentTimeMillis();
		System.out.println("Start Time:: " + startTime);
		CompletableFuture<Employee> employeeFuture = getDataFromDb(empId);
		CompletableFuture<Long> salaryFuture = getDataFromApi(empId);
		CompletableFuture.allOf(employeeFuture, salaryFuture).join();
		Employee employee = employeeFuture.get();
		Long salary = salaryFuture.get();
		long endTime = System.currentTimeMillis();
		System.out.println("End Time:: " + endTime);
		long diff = endTime - startTime;
		System.out.println("Differnce in getEmployeeDetails: " + diff);
		return new EmployeeAsynResponse(employee, salary);
	}

	public Employee saveEmployee(Employee employee) {
		return employeeRepository.save(employee);
	}

	// Method for sequential call
	/*
	 * public EmployeeResponse getEmployeeDetails1(Long empId) {
	 * 
	 * Employee emp = employeeRepository.findById(empId).orElseThrow(() -> new
	 * RuntimeException("Employee not found"));
	 * 
	 * String salaryApiUrl = "http://localhost:8081/api/employee/salary/" + empId;
	 * 
	 * // Calling external Salary URL using Rest Tempate Long salary =
	 * restTemplate.getForObject(salaryApiUrl, Long.class);
	 * System.out.println("Salary:: " + salary);
	 * 
	 * EmployeeResponse response = new EmployeeResponse();
	 * response.setEmpId(emp.getEmpId()); response.setName(emp.getName());
	 * response.setAddress(emp.getAddress());
	 * response.setDepartment(emp.getDepartment()); response.setSalary(salary !=
	 * null ? salary : 0.0);
	 * 
	 * return response; }
	 */
}
