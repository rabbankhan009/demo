package com.example.demo.controller;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.concurrent.ExecutionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.User;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.DTO.EmployeeAsynResponse;
import com.example.demo.DTO.EmployeeResponse;
import com.example.demo.service.CustomUserDetails;
import com.example.demo.service.EmployeeService;

@RestController
@RequestMapping("/api/employee")
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;

	@GetMapping("/getEmployee/{empId}")
	public ResponseEntity<EmployeeAsynResponse> getEmployee(@PathVariable Long empId, Authentication authentication)
			throws InterruptedException, ExecutionException {
		
		long startTime = System.currentTimeMillis();
		System.out.println("Start Time:: " + startTime);
		// CustomUserDetails userDetails = (CustomUserDetails)
		// authentication.getPrincipal();
		org.springframework.security.core.userdetails.User user = (User) authentication.getPrincipal();
		// System.out.println(user.get);

		boolean isCEO = user.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_CEO"));
		// System.out.println(isCEO);

		if (isCEO) {
			// return ResponseEntity.ok(employeeService.getEmployeeDetails(empId));
			return ResponseEntity.ok(employeeService.getEmployeeDetails(empId));
		}
		char empIdLoggedIn = user.getUsername().charAt(user.getUsername().length() - 1);
		System.out.println(empIdLoggedIn);
		if (!isCEO && (Character.getNumericValue(empIdLoggedIn) != empId)) {
			return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
		}

		long endTime = System.currentTimeMillis();
		System.out.println("End Time:: " + endTime);
		long diff = endTime - startTime;
		System.out.println("Differnce in controller getEmployee method : " + diff);
		return ResponseEntity.ok(employeeService.getEmployeeDetails(empId));
	}

	/*
	 * @GetMapping("/{empId}") public ResponseEntity<EmployeeResponse>
	 * getEmployee(@PathVariable Long empId) { return
	 * ResponseEntity.ok(employeeService.getEmployeeDetails(empId)); }
	 */

	@PostMapping("/saveEmployee")
	public ResponseEntity<com.example.demo.model.Employee> saveEmployee(
			@RequestBody com.example.demo.model.Employee employee) {

		long startTime1 = System.currentTimeMillis();
		System.out.println(startTime1);
		com.example.demo.model.Employee savedEmployee = employeeService.saveEmployee(employee);
		long endTime1 = System.currentTimeMillis();
		System.out.println(endTime1);
		long diff = endTime1 - startTime1;
		System.out.println("Differnce in controller for save method:: " + diff);
		return ResponseEntity.ok(savedEmployee);
	}

	@GetMapping("/salary/{empId}")
	public Long getEmployeeSalary(@PathVariable Long empId) {

		return 100L;
	}

}
