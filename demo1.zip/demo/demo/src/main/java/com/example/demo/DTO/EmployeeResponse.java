package com.example.demo.DTO;

public class EmployeeResponse {

	private Long empId;
    private String name;
    private String address;
    private String department;
    private double salary;
	public EmployeeResponse() {
		super();
	}
	public EmployeeResponse(Long empId, String name, String address, String department, double salary) {
		super();
		this.empId = empId;
		this.name = name;
		this.address = address;
		this.department = department;
		this.salary = salary;
	}
	public Long getEmpId() {
		return empId;
	}
	public void setEmpId(Long empId) {
		this.empId = empId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "EmployeeResponse [empId=" + empId + ", name=" + name + ", address=" + address + ", department="
				+ department + ", salary=" + salary + "]";
	}
    
    
}
