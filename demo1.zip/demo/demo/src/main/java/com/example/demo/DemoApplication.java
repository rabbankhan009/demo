package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

import com.example.demo.repo.EmployeeRepository;

@EnableAsync
@SpringBootApplication
public class DemoApplication {

	@Autowired
	private EmployeeRepository employeeRepository;

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

	/*
	 * @Override public void run(String... args) { // Initial sample data
	 * employeeRepository.save(new Employee(1L, "John Doe", "123 Street", "IT"));
	 * employeeRepository.save(new Employee(2L, "Jane Smith", "456 Road", "HR")); }
	 */

}
