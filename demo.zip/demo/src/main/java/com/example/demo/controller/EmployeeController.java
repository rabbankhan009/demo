package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.User;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.DTO.EmployeeResponse;
import com.example.demo.service.CustomUserDetails;
import com.example.demo.service.EmployeeService;

@RestController
@RequestMapping("/api/employee")
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;

	@GetMapping("/getEmployee/{empId}")
	public ResponseEntity<EmployeeResponse> getEmployee(@PathVariable Long empId, Authentication authentication) {
		// CustomUserDetails userDetails = (CustomUserDetails)
		// authentication.getPrincipal();
		org.springframework.security.core.userdetails.User user = (User) authentication.getPrincipal();
		// System.out.println(user.get);

		boolean isCEO = user.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_CEO"));
		System.out.println(isCEO);
		
		if (isCEO) {
			return ResponseEntity.ok(employeeService.getEmployeeDetails(empId));
		}
		char empIdLoggedIn = user.getUsername().charAt(user.getUsername().length() - 1);
		System.out.println(empIdLoggedIn);
		if (!isCEO && (Character.getNumericValue(empIdLoggedIn) != empId)) {
			return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
		}

		return ResponseEntity.ok(employeeService.getEmployeeDetails(empId));
	}

	/*
	 * @GetMapping("/{empId}") public ResponseEntity<EmployeeResponse>
	 * getEmployee(@PathVariable Long empId) { return
	 * ResponseEntity.ok(employeeService.getEmployeeDetails(empId)); }
	 */

	@PostMapping("/saveEmployee")
	public ResponseEntity<com.example.demo.model.Employee> saveEmployee(
			@RequestBody com.example.demo.model.Employee employee) {
		com.example.demo.model.Employee savedEmployee = employeeService.saveEmployee(employee);
		return ResponseEntity.ok(savedEmployee);
	}

	@GetMapping("/salary/{empId}")
	public Long getEmployeeSalary(@PathVariable Long empId) {

		return 20L;
	}

}
