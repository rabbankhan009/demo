package com.example.demo.DTO;

public class Salary{
	
	private Long empId;
    private double amount;
	public Salary() {
		super();
	}
	public Salary(Long empId, double amount) {
		super();
		this.empId = empId;
		this.amount = amount;
	}
	public Long getEmpId() {
		return empId;
	}
	public void setEmpId(Long empId) {
		this.empId = empId;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "Salary [empId=" + empId + ", amount=" + amount + "]";
	}
    
    

}
