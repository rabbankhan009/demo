package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.demo.DTO.EmployeeResponse;
import com.example.demo.DTO.Salary;
import com.example.demo.model.Employee;
import com.example.demo.repo.EmployeeRepository;
@Service
public class EmployeeService {

	 @Autowired
	    private EmployeeRepository employeeRepository;

	    @Autowired
	    private RestTemplate restTemplate;

	    public EmployeeResponse getEmployeeDetails(Long empId) {
	        Employee emp = employeeRepository.findById(empId)
	                .orElseThrow(() -> new RuntimeException("Employee not found"));

	        
	        String salaryApiUrl = "http://localhost:8081/api/employee/salary/" + empId;
	        
	        //Calling external Salary URL using Rest Tempate
	        Long salary = restTemplate.getForObject(salaryApiUrl, Long.class);

	        EmployeeResponse response = new EmployeeResponse();
	        response.setEmpId(emp.getEmpId());
	        response.setName(emp.getName());
	        response.setAddress(emp.getAddress());
	        response.setDepartment(emp.getDepartment());
	        response.setSalary(salary != null ? salary : 0.0);

	        return response;
	    }

	    public Employee saveEmployee(Employee employee) {
	        return employeeRepository.save(employee);
	    }
}
