package com.example.demo.config;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.web.client.RestTemplate;

import com.example.demo.service.CustomUserDetails;

@Configuration
public class AppConfig {
    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }
    
    @Bean
    public UserDetailsService userDetailsService() {
        List<UserDetails> users = new ArrayList<>();

        users.add(new CustomUserDetails(1L, "employee1", "{noop}password", List.of(new SimpleGrantedAuthority("ROLE_EMPLOYEE"))));
        users.add(new CustomUserDetails(2L, "ceo", "{noop}password", List.of(new SimpleGrantedAuthority("ROLE_CEO"))));
        users.add(new CustomUserDetails(3L, "employee3", "{noop}password", List.of(new SimpleGrantedAuthority("ROLE_EMPLOYEE")))); 

        return new InMemoryUserDetailsManager(users);
        
    }
}